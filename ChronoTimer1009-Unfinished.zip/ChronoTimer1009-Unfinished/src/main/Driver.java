package main;

import java.io.IOException;

public class Driver {
	
	public static void main(String[] args) {
		
		
		
		Simulator sim = new Simulator();
		sim.start();
		
	}
}